#pragma once
#include <Windows.h>
// una de las siguientes dos líneas según la organización del proyecto
#include "glad.h" // OpenGL Loader Generator
#include <GL/freeglut.h> // OpenGL Utility Toolkit
#include <glm.hpp> // OpenGL Mathematics